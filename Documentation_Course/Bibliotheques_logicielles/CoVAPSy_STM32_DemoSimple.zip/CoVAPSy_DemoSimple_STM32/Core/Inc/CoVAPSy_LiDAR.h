/*
 * bno055.h
 *
 *  Created on: Oct 2 , 2023
 *      Author: aazan
 */

#ifndef INC_COVAPSY_LiDAR_H_
#define INC_COVAPSY_LiDAR_H_



void LiDAR_init(void);


#endif /* INC_COVAPSY_LiDAR_H_ */
